@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">About</div>
        
                

                <div class="panel-body" >
<div >
                <p>My name is Ronald Barry V. Bonje. 23 years of age and i am residing at lahug cebu city. I am a 3rd
                    year student at University of Cebu - Main Campus taking of Bachelor of Science in Information Technology.
                    I am the youngest and the oldest son, in short i am the only son.  
                </p>
                                   <p>
Back to my childhood days I’m a type of guy that innocent and shy I don’t always talk to my family even with my friends. I think that my star sign can tell you a lot about me, my inside world, soul and character. I believe that stars influence our fate and character, though I don't trust daily horoscopes. I was born under the zodiac sign of Capricorn Stars affirm that Capricorn are active and artistic. These people admire adventures and changes, they make friends with unusual lightness and they are excellent mates too. My friends consider me to be rather earnest guy, because I always think about anything, but all of them know me as a faithful and responsive friend, I'm always eager to help my friends and to calm them with the help of a tender word.School meant very much to me and I'm sure that it gave me a lot, first of all of course in educational sphere. Thanks to school and my teachers I became more educated person. I consider that I became more persistent, determined and ambitious. Diligence, attention and accuracy all these qualities school developed in me regularly. And owning to school I got acquainted with interesting people, devoted friends and excellent teachers. But like other people I'm not an ideal. I can't wait for long that's why I can be called an impatient person. Sometimes I can be lazy, but I always try to fight with this feature of my character. Also I can be very sensitive I can't say that it's a negative trait of my character but I dislike it a bit.

                 </p>
</div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
