<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">About</div>
                
                <p> My name is Ellem G. Tan I’m 23 years old I live in 153-A Colveta II Tabada St. Mambaling Cebu City. 
                I currently study in University of Cebu taking up Bachelor Science Information Technology. 
                Before I back in school I worked as Sales Associate in Rustans Commercial Corporation as Sales Associate.
                 In my Family I’m the youngest I have 8 siblings, 3 bothers and 5 sisters we love to hangout like we are best friends we go to the places that we never go before. We are also religious family we go to church every Sunday. About my hobbies I love to watch movies, read novels and listening to my favorite musics and I like to hangout with my family and friends. In spite of those happy moments in my life I also experience trials, Trials in my family and friends but with God I survived.
                </p>
                <br>
                <p>
Back to my childhood days I’m a type of girl that innocent and shy I don’t always talk to my family even with my friends. I think that my star sign can tell you a lot about me, my inside world, soul and character. I believe that stars influence our fate and character, though I don't trust daily horoscopes. I was born under the zodiac sign of Libra Stars affirm that Libra are active and artistic. These people admire adventures and changes, they make friends with unusual lightness and they are excellent mates too. My friends consider me to be rather earnest girl, because I always think about anything, but all of them know me as a faithful and responsive friend, I'm always eager to help my friends and to calm them with the help of a tender word.School meant very much to me and I'm sure that it gave me a lot, first of all of course in educational sphere. Thanks to school and my teachers I became more educated person. I consider that I became more persistent, determined and ambitious. Diligence, attention and accuracy all these qualities school developed in me regularly. And owing to school I got acquainted with interesting people, devoted friends and excellent teachers. But like other people I'm not an ideal. I can't wait for long that's why I can be called an impatient person. Sometimes I can be lazy, but I always try to fight with this feature of my character. Also I can be very sensitive I can't say that it's a negative trait of my character but I dislike it a bit.

                 </p>

                <div class="panel-body">
                   
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>