<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">My Subjects</div>

                <div class="panel-body">
                   <table class="table table-striped" style="width: 100%;">
                       <tr>
                           <th>EDP CODE</th>
                           <th>SUBJECT NAME</th>
                           <th>DESCRIPTION</th>
                           <th>SCHEDULE</th>
                           <th>UNIT</th>
                       </tr>
                       <tr>
                           <td>05217</td>
                           <td>ITELECPHP2 (LAB)</td>
                           <td>IT Elective (PHP Programming 2)</td>
                           <td>6:30 - 7:30 PM / MW</td>
                           <td>3</td>
                       </tr>
                        <tr>
                           <td>05217</td>
                           <td>ITELECPHP2 (LEC)</td>
                           <td>IT Elective (PHP Programming 2)</td>
                           <td>7:30 - 8:30 PM / MWF</td>
                           <td>3</td>
                       </tr>
                       <tr>
                           <td>00281</td>
                           <td>FREEELPM</td>
                           <td>INTRODUCTION TO PROJECT MANAGEMENT</td>
                           <td>8:00 - 9:30 PM / TTH</td>
                           <td>3</td>
                       </tr>
                       <tr>
                           <td>03194</td>
                           <td>Res1</td>
                           <td>Research 1</td>
                           <td>12:00 - 1:30 PM / TTH</td>
                           <td>3</td>
                       </tr>
                       <tr>
                           <td>09122</td>
                           <td>Database 32 (LAB)</td>
                           <td>Database 32</td>
                           <td>2:30 - 3:30 PM / MWF</td>
                           <td>3</td>
                       </tr>
                       <tr>
                           <td>09122</td>
                           <td>Database 32 (LEC)</td>
                           <td>Database 32</td>
                           <td>1:30 - 2:30 PM / TTH</td>
                           <td>3</td>
                       </tr>
                       <tr>
                           <td>02862</td>
                           <td>Mgt1A</td>
                           <td>Management</td>
                           <td>5:30 - 6:30 PM / MWF</td>
                           <td>3</td>
                       </tr>
                       <tr>
                           <td>15742</td>
                           <td>Rizal</td>
                           <td>Life of Jose Rizal</td>
                           <td>1:30 - 2:30 PM / MWF</td>
                           <td>3</td>
                       </tr>
                   

                   </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>